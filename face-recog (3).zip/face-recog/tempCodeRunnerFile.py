now=datetime.now()
current_date=now.strftime(r"%Y-%m-%d")
f=open(f'{current_date}.csv','w+',newline='')
lnwriter=csv.writer(f)